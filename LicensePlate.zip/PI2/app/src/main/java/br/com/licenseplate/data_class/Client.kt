package br.com.licenseplate.data_class

data class Client(
    val nome: String,
    val cpf: String,
    val cel: String
)