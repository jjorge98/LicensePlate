package br.com.licenseplate.views.activities.client

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import br.com.licenseplate.R

class HelpLicenseRequest : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_license_request)
    }
}
