package br.com.licenseplate.data_class

data class Stamper(
    val nome: String,
    val cpf: String,
    val rg: String,
    val tipo_login: Int
)