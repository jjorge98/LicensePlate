package br.com.licenseplate.data_class

data class Store (
    val nome: String,
    val carro: Double,
    val moto: Double,
    val localizacao: String
)